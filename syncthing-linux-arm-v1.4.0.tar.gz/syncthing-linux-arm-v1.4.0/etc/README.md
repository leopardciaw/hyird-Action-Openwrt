This directory contains contributed setup examples.
